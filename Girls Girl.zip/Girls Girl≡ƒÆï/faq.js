function toggleFaq(faqHeader) {
    faqHeader.classList.toggle('open');
    faqHeader.nextElementSibling.classList.toggle('open');
}